juxtapo.designs.LayoutTemplate.defaultStyles = { 
			position: 'absolute', 
			'z-index': '2000', 
			top: '0px', 
			left: '50%', 
			'margin-left': '-375px' 
};

juxtapo.addTemplate('design1.htm',	'design1.png', {top: '8px'});
juxtapo.addTemplate('design2.htm',	'design2.png', { left:"0",'margin-left':'0'});
