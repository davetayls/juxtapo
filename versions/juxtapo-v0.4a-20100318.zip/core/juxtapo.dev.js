

/**
 * juxtapo JavaScript Library http://juxtapo.net/
 *
 * Copyright (c) 2009 David Taylor (@davetayls) Licensed under the GNU v3
 * license. http://www.gnu.org/licenses/gpl.html
 * 
 * Version 0.4a
 *
 */



(function(){

    /* private */
	var _coreJsUrl = ''
    
    // Methods
    function addResources(){
        if (juxtapo.coreJsUrl()) {
            juxtapo.utils.requireResource(juxtapo.coreJsUrl() + 'juxtapo.css');
        }
    };
    function initContainer(){
        juxtapo.container = document.createElement("div");
        $(juxtapo.container).attr("id", "juxtapo-container");
        $("body").append(juxtapo.container);
        /*
         * if (juxtapo.utils.is.ie && juxtapo.utils.is.version == 6){
         * $(juxtapo.container).css({position:"absolute",top:"0",left:"0"}); }
         */
    };
    function initStatus(){
        // get current status
        s = juxtapo.utils.getQuery("status");
        if (s) {
            juxtapo.currentStatus = s;
        }
        else {
            juxtapo.currentStatus = juxtapo.statuses.pause;
        }
    };
    
    // events
    var onInitComplete = function(){
        $(juxtapo).trigger("_initComplete");
    };
    var onInitConfig = function(){
        $(juxtapo).trigger("_initConfig");
    };
    
    /* public */
	/**
	 * Juxtapo library 
	 * @class
	 * @name juxtapo
     * @property {HtmlElement} container
     * @property {HtmlElement} controller
     * @property {juxtapo.designViews} currentDesignView
     * @property {juxtapo.statuses} currentStatus
     * @property {bool} designvisible
     * @property {int} designCurrentImageIndex
     * @property {juxtapo.designs.designTemplate[]} designTemplates Array of {@link juxtapo.designs.designTemplate} which describe the designs within the project
     * @property {Object} globalSettings
     * @property {int} secondsBeforeRefresh
	 */
    juxtapo = {
		version : '0.4a',
		/**
		 * The various states the auto refresh can be in
		 * @constant
		 * @default pause:2
		 * @field
		 * @type Object {off,play,pause}
		 */
        statuses: {
            off: 0,
            play: 1,
            pause: 2
        },
		/**
		 * The states to choose the transparency of the design
		 * @constant
		 * @type Object {hidden,semiTransparent,opaque}
		 */
        designViews: {
            hidden: 0,
            semiTransparent: 1,
            opaque: 2
        },
        
        // Properties
        container: null,
        controller: null,
        currentDesignView: 0,
        currentStatus: 2,
        //designlayout: null,
        designvisible: false,
        designCurrentImageIndex: 0,
        designTemplates: [], // list of layout images to place as the
		globalSettings:{},
        coreJsUrl: function(){
	        if (_coreJsUrl == '') _coreJsUrl = juxtapo.utils.getJsLocation('juxtapo.js');
			return _coreJsUrl;
		},
        secondsBeforeRefresh: 2.5,
        timerId: -1,
        
        // methods
		/**
		 * Initialises juxtapo
		 * @private
		 */
        init: function(){
            addResources();
			onInitConfig();
            initStatus();
            
            // init if not turned off
            if (juxtapo.currentStatus != juxtapo.statuses.off) {
                initContainer();
                juxtapo.designs.init();
                juxtapo.control.init();
            }
            juxtapo.eh.init();
            juxtapo.thumbs.init();
            
            juxtapo.utils.getKeyCombination("13+shift");
            
            onInitComplete();
        },
		/**
		 * Adds plugin files to juxtapo
		 * @param {Object} pluginPaths An array of paths to plugins relative to the juxtapo.js
		 * @example
		 * juxtapo.addPlugins(['../plugins/juxtapo.views.js']);
		 */
        addPlugins : function(pluginPaths){
			for (var i=0;i<pluginPaths.length;i++){
				var jsLoc = juxtapo.utils.resolveAbsoluteUrl(juxtapo.coreJsUrl(),pluginPaths[i]);
				document.write("<script type=\"text/javascript\" src=\"" + jsLoc + "\"></script>");
			}
		},
        /**
         * Adds a juxtapo.designs.designTemplate object to the designTemplates
         * array
         *
         * @param {String}
         *            imageUrl
         * @param {Array}
         *            paths An array of urls to match this image with
         * @param {Object}
         *            Object with the following settings
         *            - style: A set of key:value pairs to customise the style from the
         *              defaultStyles
         *            - data: A set of key:value pairs to be associated with the template 
         * @return {juxtapo.designs.designTemplate} Returns the new template
         */
        addTemplate: function(path, imageUrl, settings){
            var t = new juxtapo.designs.designTemplate(imageUrl, [path], settings);
            this.designTemplates.push(t);
            return t;
        },
        /**
         * This sets the default styles applied to each design template
         * image when added to the page.
         * @param {Object} styles
         */
		setDefaultStyles : function(styles){
			juxtapo.designs.designTemplate.defaultStyles = styles;
		},
        // events
		/**
		 * Adds a listener function which gets fired when juxtapo
		 * needs the configuration to be initialised
		 * @event
		 * @example
		 * juxtapo.iniConfig(function(ev){
		 * 		juxtapo.addTemplate('path.htm','image.png',{}); 
		 * });
		 * @param {Function} fn(ev)
		 */
        initConfig: function(fn){
            $(juxtapo).bind("_initConfig", fn);
        },
		/**
		 * Adds a listener to the initComplete event
		 * @event
		 * @example
		 * juxtapo.iniComplete(function(ev){ run code here... });
		 * @param {Function} fn(ev)
		 */
        initComplete: function(fn){
            $(juxtapo).bind("_initComplete", fn);
        }
        
    };
    
    // Methods
    
	/**
	 * Listener attached to the keydown event on the body
	 * @private
	 */
    juxtapo.onBody_KeyDown = function(e){
        var keycode;
        if (window.event) 
            keycode = window.event.keyCode;
        else 
            if (e) 
                keycode = e.which;
            else 
                return true;
        
        juxtapo.eh.logInfo("keycode is: " + keycode); // ##DEBUG
        // Check if user presses Ctl+o or Ctl+right
        if (e.ctrlKey && (keycode == 79 || keycode == 39)) {
            juxtapo.designs.forward();
            juxtapo.utils.preventDefaultEventAction(e);
            return false;
        }
        // Check if user presses Ctl+u or Ctl+left
        if (e.ctrlKey && (keycode == 85 || keycode == 37)) {
            juxtapo.designs.back();
            juxtapo.utils.preventDefaultEventAction(e);
            return false;
        }
        // Check if user presses Ctl+up-arrow
        if (e.ctrlKey && keycode == 38) {
            juxtapo.designs.change(true);
            juxtapo.utils.preventDefaultEventAction(e);
            return false;
        }
        // Check if user presses Ctl+down-arrow
        if (e.ctrlKey && keycode == 40) {
            juxtapo.designs.change(false);
            juxtapo.utils.preventDefaultEventAction(e);
            return false;
        }
        // Ctl+Space
        if (e.ctrlKey && keycode == 32) {
            juxtapo.control.toggle();
            juxtapo.utils.preventDefaultEventAction(e);
            return false;
        }
        // nudge designs
        if (e.ctrlKey && keycode == 73) {
            var pixels = e.shiftKey ? 1 : 25;
            juxtapo.designs.nudge("top", pixels);
            juxtapo.utils.preventDefaultEventAction(e);
            return false;
        }
        if (e.ctrlKey && keycode == 76) {
            var pixels = e.shiftKey ? 1 : 25;
            juxtapo.designs.nudge("right", pixels);
            juxtapo.utils.preventDefaultEventAction(e);
            return false;
        }
        if (e.ctrlKey && keycode == 75) {
            var pixels = e.shiftKey ? 1 : 25;
            juxtapo.designs.nudge("bottom", pixels);
            juxtapo.utils.preventDefaultEventAction(e);
            return false;
        }
        if (e.ctrlKey && keycode == 74) {
            var pixels = e.shiftKey ? 1 : 25;
            juxtapo.designs.nudge("left", pixels);
            juxtapo.utils.preventDefaultEventAction(e);
            return false;
        }
        
        return true;
    };
	/** @private */
    juxtapo.onMouseMove = function(){
        clearTimeout(juxtapo.timerId);
        if (juxtapo.currentStatus == juxtapo.statuses.play) {
            juxtapo.timerId = setTimeout('juxtapo.control.reload()', juxtapo.secondsBeforeRefresh * 1000);
        }
    };
    
})();

if (window.addEventListener) {
    window.addEventListener('load', juxtapo.init, false);
}
else 
    if (window.attachEvent) {
        window.attachEvent('onload', juxtapo.init);
    }


/**
 * @author david
 */
/*
 juxtapo.eh
 -----------------------------------------------------------*/
(function(){

    var _dropDown = null;

	/**
	 * Error handler
	 * @namespace
	 */    
    juxtapo.eh = {
        // properties
        errors: "",
        hasError: false,
        initCompleted: false,
        
        // methods
		dropDown : function(){
			return _dropDown;
		},
        init: function(){
        
            _dropDown = new juxtapo.ui.dropDown({style:{height:'300px',width:'450px'}});
            _dropDown.text("e");
			$(_dropDown.contents).addClass("juxtapo-errorBox");
                        
            juxtapo.eh.renderErrors();
			/*
			$(window).bind("onerror",function(e){
				juxtapo.eh.logError(e);
			});*/
            this.initCompleted = true;
        },
        logInfo: function(message){
            juxtapo.eh.errors = "<li class=\"juxtapo-info\">" + "[" + juxtapo.utils.date.toShortTimeString(new Date()) + "] " + message + "</li>"+juxtapo.eh.errors;
            juxtapo.eh.renderErrors();
            return juxtapo.eh.errors;
        },
        logError: function(err){
            if (typeof(err) == "string") {
                juxtapo.eh.errors = "<li class=\"juxtapo-error\">" + err + "</li>"+juxtapo.eh.errors;
            }else if (typeof(err) == "object") {
				juxtapo.eh.errors = "<li class=\"juxtapo-error\">[object]" + juxtapo.utils.objectToStructureString(err) + "</li>"+juxtapo.eh.errors;
			}
			else {
				juxtapo.eh.errors += "<li class=\"juxtapo-error\">" + err.message + "</li>";
			}
            juxtapo.eh.hasError = true;
            juxtapo.eh.renderErrors();
            return juxtapo.eh.errors;
        },
        renderErrors: function(){
            if (_dropDown) {
                _dropDown.contentHtml("<ul>"+juxtapo.eh.errors+"</ul>");

				$(_dropDown.controller).removeClass("juxtapo-eh-error");
                if (juxtapo.eh.hasError === true) {
                    $(_dropDown.controller).addClass("juxtapo-eh-error");
                    _dropDown.text("!");
                }
                else {
                    _dropDown.text("e");
                }
            }
            return true;
        },
        showErrorBox: function(b){
            juxtapo.eh.errorsBoxVisible = b;
            if (b) {
                $(juxtapo.eh.errorsBox).show(100);
            }
            else {
                $(juxtapo.eh.errorsBox).hide(100);
            }
        },
        toggleErrorBox: function(){
            juxtapo.eh.showErrorBox(!juxtapo.eh.errorsBoxVisible);
        }
        
    }; // juxtapo.eh
})();




/*
 * juxtapo.control
 */
(function(){
	/**
	 * The control name
	 * @namespace
	 * @property {bool} initCompleted Set to true at the end of the init function 
	 */
	juxtapo.control = {
		
		// properties
		initCompleted:false,
		
		// methods
		init : function(){
		    // controller
		    juxtapo.controller = document.createElement("div");
		    //$(juxtapo.controller).attr("style", "border: solid 1px #ccc; position: fixed; top:0; left:0; width: 5px; height: 6px; font-weight: bold; text-align: center; padding: 3px; cursor: pointer; background-color: white; font-size: 5px; z-index: 2000;");
			$(juxtapo.controller).attr("class","juxtapo-btn");
		    juxtapo.controller.onclick = juxtapo.control.toggle;
		    juxtapo.container.appendChild(juxtapo.controller);	
		
		    window.onmousemove = juxtapo.onMouseMove;
		    if (juxtapo.currentStatus == juxtapo.statuses.pause) {
		        juxtapo.control.pause();
		    } else {
		        juxtapo.control.play();
		    }
			this.initCompleted = true;
		},
		/**
		 * Sets the currentStatus to play and begins
		 * automatically refreshing the page
		 * @return {int} returns the int value of juxtapo.statuses.play
		 */
		play : function() {
		    juxtapo.currentStatus = juxtapo.statuses.play;
		    juxtapo.controller.innerHTML = "|&nbsp;|";
		    juxtapo.timerId = setTimeout('juxtapo.control.reload()', juxtapo.secondsBeforeRefresh * 1000);
			return juxtapo.currentStatus;
		},
		pause : function() {
		    juxtapo.currentStatus = juxtapo.statuses.pause;
		    juxtapo.controller.innerHTML = ">";
		    clearTimeout(juxtapo.timerId);
		    //reloadUrl = "http://" + location.host + location.pathname + "?status=" + juxtapo.currentStatus + "&design=" + juxtapo.designvisible + "&v=" + $(document).scrollTop() + "&dv=" + juxtapo.currentDesignView;
		    //location.href = reloadUrl;
			return juxtapo.currentStatus;
		},
		reload : function() {
		    if (juxtapo.currentStatus == juxtapo.statuses.play) {
		        reloadUrl = "http://" + location.host + location.pathname + "?r=" + new Date().toString() + "&status=" + juxtapo.currentStatus + "&design=" + juxtapo.designvisible + "&v=" + $(document).scrollTop() + "&dv=" + juxtapo.currentDesignView + "&di=" + juxtapo.designCurrentImageIndex;
		        location.href = reloadUrl;
		    }
		},
		toggle : function() {
		    if (juxtapo.currentStatus == juxtapo.statuses.pause) {
		        return juxtapo.control.play();
		    } else {
		        return juxtapo.control.pause();
		    }
		}
	};
	
})();


/**
 * @author david
 * @namespace juxtapo.designs
 */
(function() {

	// properties
	var _designImageElement = null;

	// events
	var onDesignPositionChanged = function(img, oldPos, newPos) {
		$(juxtapo).trigger("_designPositionChanged", [ img, oldPos, newPos ]);
	};

	/* public */
	/**
	 * Designs
	 * @namespace
	 */
	juxtapo.designs = {
		// methods
		back : function() {
			if (juxtapo.currentDesignView == juxtapo.designViews.hidden) {
				juxtapo.designs.show();
			} else if (juxtapo.currentDesignView == juxtapo.designViews.semiTransparent) {
				juxtapo.designs.hide();
			} else {
				juxtapo.designs.semiTransparent();
			}
		},
		change : function(previous) {
			if (previous) {
				newIndex = juxtapo.designCurrentImageIndex - 1;
				if (newIndex < 0)
					newIndex = juxtapo.designTemplates.length - 1;
			} else {
				newIndex = juxtapo.designCurrentImageIndex + 1;
				if (newIndex > juxtapo.designTemplates.length - 1)
					newIndex = 0;
			}
			juxtapo.designs.changeTo(newIndex);
		},
		changeTo : function(item) {
			var design = null;
			if (typeof (item) == "undefined") {
				return false;
			} else if (typeof (item) == "object") {
				design = item;
			} else {
				juxtapo.designCurrentImageIndex = item;
				design = juxtapo.designTemplates[item];
			}
			var designStyle = $.extend({},juxtapo.designs.designTemplate.defaultStyles,design.settings.style);
			$("#design").attr("src", design.imageUrl).css(designStyle);
		},
		currentDesign : function(){
			return juxtapo.designTemplates[juxtapo.designCurrentImageIndex];
		},
		designImageElement : function(el) {
			if (typeof (el) != "undefined") {
				_designImageElement = el;
			} else if (!_designImageElement) {
				_designImageElement = document.getElementById("design");
			}
			return _designImageElement;
		},
		filterBySearch : function(q) {
			var results = null;
			var thumbs = [];
			if (q == "") {
				$("#juxtapo-thumbs-container li").show();
			} else {
				results = this.search(q);
				$("#juxtapo-thumbs-container li").hide();
				for ( var i = 0; i < results.designs.length; i++) {
					var design = results.designs[i]
					design.thumbnail.show();
				}
			}
			return {
				"q" : q,
				"designs" : results
			};
		},
		forward : function() {
			if (juxtapo.currentDesignView == juxtapo.designViews.hidden) {
				juxtapo.designs.semiTransparent();
			} else if (juxtapo.currentDesignView == juxtapo.designViews.semiTransparent) {
				juxtapo.designs.show();
			} else {
				juxtapo.designs.hide();
			}
		},
		getAll : function(){
			return juxtapo.designTemplates;
		},
		getDesignFromUrl : function(url) {
			var href = url.toLowerCase();
			for ( var i = 0; i < juxtapo.designTemplates.length; i++) {
				layout = juxtapo.designTemplates[i];
				for ( var p = 0; p < layout.paths.length; p++) {
					path = layout.paths[p].toLowerCase();
					if (href.juxtapoContains(path)) {
						juxtapo.designCurrentImageIndex = i;
						return layout;
					}
				}
			}
			;
			return juxtapo.designTemplates[0];
		},
		hide : function() {
			$("#design").css("display", "none");
			juxtapo.designvisible = false;
			juxtapo.currentDesignView = juxtapo.designViews.hidden;
		},
		init : function() {
			// add design image to page
			$('<img id="design" src="noimage.jpg" alt="design image" />')
					.appendTo("body").css( {
						display : 'none'
					});

			if (juxtapo.utils.getQuery("di") != null) {
				juxtapo.designs
						.changeTo(parseInt(juxtapo.utils.getQuery("di")));
			} else {
				juxtapo.designs.changeTo(juxtapo.designs
						.getDesignFromUrl(location.href));
			}
			$(document).keydown(juxtapo.onBody_KeyDown);

			// design controller button
			juxtapo.designlayout = document.createElement("div");
			$(juxtapo.designlayout).attr("class", "juxtapo-btn");
			juxtapo.designlayout.onclick = juxtapo.designs.toggle;
			juxtapo.designlayout.innerHTML = "D E S I G N";
			juxtapo.container.appendChild(juxtapo.designlayout);
			d = juxtapo.utils.getQuery("design");
			if (d != null) {
				juxtapo.designvisible = d;
			}
			dv = juxtapo.utils.getQuery("dv");
			if (!dv) {
				dv = juxtapo.currentDesignView;
			}
			if (dv != null) {
				if (dv == juxtapo.designViews.hidden) {
					juxtapo.designs.hide();
				} else if (dv == juxtapo.designViews.semiTransparent) {
					juxtapo.designs.semiTransparent();
				} else {
					juxtapo.designs.show();
				}
			}

			// reset scroll position
			v = juxtapo.utils.getQuery("v");
			if (v) {
				$(document).scrollTop(v);
			}

		},
		nudge : function(dir, pixels) {
			if (dir == "")
				return false;
			if (typeof (pixels) == "undefined")
				pixels = 1;
			var $img = $(this.designImageElement());
			var oldPos = {
				offSet : $img.offset(),
				position : $img.position()
			};
			switch (dir) {
			case "top":
				var currentTop = parseInt($("#design").css("top"));
				$img.css("top", currentTop - pixels);
				break;
			case "right":
				var currentLeft = parseInt($("#design").css("margin-left"));
				$img.css("margin-left", currentLeft + pixels);
				break;
			case "bottom":
				var currentTop = parseInt($("#design").css("top"));
				$img.css("top", currentTop + pixels);
				break;
			case "left":
				var currentLeft = parseInt($("#design").css("margin-left"));
				$img.css("margin-left", currentLeft - pixels);
				break;
			}
			var newPos = {
				offSet : $img.offset(),
				position : $img.position()
			};
			onDesignPositionChanged($img.get(0), oldPos, newPos);
		},
		search : function(q) {
			var results = {
				designs : [],
				indexes : []
			};
			if (q != "") {
				q = q.toLowerCase();
				for ( var i = 0; i < juxtapo.designTemplates.length; i++) {
					var iDesign = juxtapo.designTemplates[i];
					if (iDesign.imageUrl.toLowerCase().indexOf(q) > -1
							|| iDesign.paths[0].toLowerCase().indexOf(q) > -1) {
						results.designs.push(iDesign);
						results.indexes.push(i);
					}
				}
			}
			return results;
		},
		show : function() {
			$("#design").css( {
				display : "block",
				opacity : "1"
			});
			juxtapo.designvisible = true;
			juxtapo.currentDesignView = juxtapo.designViews.opaque;
			return juxtapo.currentDesignView;
		},
		semiTransparent : function() {
			$("#design").css( {
				display : "block",
				opacity : "0.5"
			});
			juxtapo.designvisible = true;
			juxtapo.currentDesignView = juxtapo.designViews.semiTransparent;
		},
		toggle : function() {
			juxtapo.designs.forward();
		},

		/* events */
		/**
		 * Adds a listener function which gets triggered when the overlay image
		 * has been moved
		 * @event
		 * @param {Object} fn(ev)
		 */
		designPositionChanged : function(fn) {
			$(juxtapo).bind("_designPositionChanged", fn);
		}
	};


	// SUB CLASSES
	/**
	 * Create a new instance of designTemplate
	 * @class designTemplate is the description of each design layout
	 * @param {Object} imageUrl
	 * @param {Object} paths
	 * @param {Object} settings Key value pair of settings
	 * @param {Object} settings.data Key:value set of meta data that can be used by plugins
	 * @param {Object} settings.style Key:value pair of css styles which will override the default styles
	 * @return {juxtapo.designs.designTemplate} Returns a new designTemplate
	 * @constructor
	 * 
	 * @property {juxtapo.ui.thumbnail} thumbnail
	 */
	juxtapo.designs.designTemplate = function(imageUrl, paths, settings) {
		this._init(imageUrl, paths, settings);
		return;
	};
	juxtapo.designs.designTemplate.prototype = {
		imageUrl : '',
		paths : [],
		settings : {
			data : {},
			style : {}
		},
		thumbnail:null,
		
		_init : function(imageUrl, paths, settings){
			var self = this;
			self.imageUrl = imageUrl;
			self.paths = paths;
			self.settings = $.extend( {}, juxtapo.designs.designTemplate.prototype.settings, settings);

			/**
			 * Sets the {@link juxtapo.ui.thumbnail} connected with this designTemplate
			 * @name juxtapo.designs.designTemplate.setUiThumbnail
			 * @function
			 * @param {juxtapo.ui.thumbnail} thumbnail
			 * @returns {juxtapo.designs.designTemplate}
			 */			
			self.setUiThumbnail = function(thumbnail){
				self.thumbnail = thumbnail;
				$(self).trigger("_thumbnailSet");
				return self;
			};
			/**
			 * Adds a listener to the thumbnailSet event which fires
			 * when the designTemplate receives a {@link juxtapo.ui.thumbnail}
			 * through the {@link juxtapo.designs.designTemplate.setUiThumbnail}
			 * method
			 * @event
			 * @example
			 * designTemplateInstance.thumbnailSet(function(ev){ code to run ... });
			 * @name juxtapo.designs.designTemplate.thumbnailSet
			 * @param {Object} fn(ev)
			 */
			self.thumbnailSet = function(fn){
				$(self).bind("_thumbnailSet",fn);
				return self;
			};

		}
	};
	juxtapo.designs.designTemplate.defaultStyles = {
		position : 'absolute',
		'z-index' : '2000',
		top : '0px',
		left : '50%',
		'margin-left' : '-550px'
	};

})();


/*
 juxtapo.thumbs
 -----------------------------------------------------------*/
(function(){

	var self;
    var _dropDown = null;
    var _$toolbar = $('<div id="juxtapo-ui-toolbar" class="juxtapo-cc" />');
    var _$toolbarLeft = $('<div id="juxtapo-ui-toolbarL" />');
    var _$toolbarRight = $('<div id="juxtapo-ui-toolbarR" />');
    var _$searchBox = $('<input id="juxtapo-searchDesigns" type="text" />');
    var _$thumbsContainer = $('<ul id="juxtapo-thumbs-container" />');
 
	/**
	 * Pop up for displaying thumbnails
	 * @namespace
	 */
    juxtapo.thumbs = {
        rendered: false,
		/**
		 * The {@link juxtapo.ui.dropDown} used by the thumbnail control
		 * @returns {juxtapo.ui.dropDown}
		 */        
		dropDown : function(){
			return _dropDown;
		},
		/** @private */
        init: function(){
			self = juxtapo.thumbs;
			_dropDown = new juxtapo.ui.dropDown();
            _dropDown.text("+");
            var thumbs = this;

			/** @private */
            _dropDown.beforeOpen = function(){
                if (!thumbs.rendered) {
                    thumbs.renderThumbs();
                }
            };
			/** @private */
            _dropDown.afterOpen = function(){
                $("#juxtapo-searchDesigns").focus();
            };
        },
		/**
		 * @param {HtmlElement} el
		 */
		appendToToolbarLeft : function(el){
			_$toolbarLeft.append(el);
			return self;
		},
		/**
		 * @param {HtmlElement} el
		 */
		appendToToolbarRight : function(el){
			_$toolbarRight.append(el);
			return self;
		},
		/** @private */
        renderThumbs: function(){
            juxtapo.eh.logInfo("thumbs rendering");
            var designList;
            designList = "";
			var windowHeight = parseInt($(window).height());
			var contentsHeight = windowHeight - 50; 
            $(_dropDown.contents)
            	.append(_$toolbar)
            	.append(_$thumbsContainer)
				.css("height", contentsHeight+'px');
            _$toolbar.append(_$toolbarLeft).append(_$toolbarRight);
            _$toolbarLeft.append(_$searchBox);
			_$thumbsContainer.css("height",(contentsHeight - 39)+'px');
            for (var i = 0; i < juxtapo.designTemplates.length; i++) {
				var thumb = new juxtapo.ui.thumbnail(juxtapo.designTemplates[i]);
				_$thumbsContainer.append(thumb.container);
            }
            $("#juxtapo-searchDesigns").keyup(this.searchKeyup);
            this.rendered = true;
            $(juxtapo.thumbs).trigger("_thumbsRendered");
        },
		/** @private */
        searchKeyup: function(e){
            juxtapo.designs.filterBySearch($("#juxtapo-searchDesigns").val());
        },
		/**
		 * The html ul element which contains the list of thumbs
		 * @returns {HtmlUlElement}
		 */
		thumbsContainer : function(){
			return _$thumbsContainer.get(0);
		},
        
        // events
        thumbsRendered : function(fn){
			$(juxtapo.thumbs).bind("_thumbsRendered", fn);
		}
    };
    
})();




(function(){

	/**
	 * Utils namespace which contains useful functions
	 * @namespace
	 */
	juxtapo.utils = {
		createCookie : function(name,value,days) {
			if (days) {
				var date = new Date();
				date.setTime(date.getTime()+(days*24*60*60*1000));
				var expires = "; expires="+date.toGMTString();
			}
			else var expires = "";
			document.cookie = name+"="+value+expires+"; path=/";
			return true;
		},
		/**
		 * Set of date functions
		 * @namespace
		 */
		date : {
			/**
			 * Returns a string with hours:minutes:seconds:milliseconds
			 * @param {Date} d
			 */
			toShortTimeString : function(d){
				return d.getHours() + ":" + d.getMinutes() + ":" + d.getSeconds() + ":" + d.getMilliseconds();  
			}		
		},
		eraseCookie : function(name) {
			self.createCookie(name,"",-1);
			return true;
		},
		/**
		 * Returns the value of a query string variable
		 * @param {String} ji The query string variable name
		 */
		getQuery : function(ji) {
		    hu = window.location.search.substring(1);
		    gy = hu.split("&");
		    for (i = 0; i < gy.length; i++) {
		        ft = gy[i].split("=");
		        if (ft[0] == ji) {
		            return ft[1];
		        }
		    }
		    return null;
		},
		is : {
			ie: navigator.appName == "Microsoft Internet Explorer",
			version: parseFloat(navigator.appVersion.substr(21)) || parseFloat(navigator.appVersion),
			win: navigator.platform == "Win32"
		},		
		getJsLocation : function(jsFileName){
			jsFileName = jsFileName.toLowerCase();
			var scriptFiles = document.getElementsByTagName("script");
			for (var i=0;i<scriptFiles.length;i++){
				var scriptTag = scriptFiles[i];
				var scriptFileName = scriptTag.src.substring(scriptTag.src.lastIndexOf("/")+1).toLowerCase();
				scriptFileName = scriptFileName.split("?")[0];
				if (scriptFileName == jsFileName){
					return scriptTag.src.substring(0,scriptTag.src.lastIndexOf("/")+1);
				}
			}
			return null;
		},
		getKeyCombination : function(combination){
			var items = combination.split("+");
			var ret = {
				ctrl: false,
				keyCode: -1,
				shift: false
			};
			for (var i=0;i<items.length;i++){
				var itm = items[i].toLowerCase();
				if (isNaN(parseInt(itm))){
					ret.shift = (ret.shift || itm == "shift");
					ret.ctrl = (ret.ctrl || itm == "ctrl");
				}else{
					ret.keyCode = parseInt(itm);	
				}
			}
			return ret;
		},
		isAbsoluteUrl : function(url) {
		    Url = url.toLowerCase();
		    if (Url.substr(0, 7) == "http://") { return true; }
		    if (Url.substr(0, 6) == "ftp://") { return true; }
		    return false;
		},
		isRelativeUrl : function(url) {
		    Url = url.toLowerCase();
		    if (Url.substr(0, 2) == "~/") { return true; }
		    if (Url.substr(0, 3) == "../") { return true; }
		    return false;
		},
		objectToStructureString : function(obj,tab,level){
			if (obj == window) return "window";
		    if (typeof(tab)=='undefined'){tab='';}
			if (typeof(level)=='undefined'){level=0;}
			var newLine = "<br />";
			var tabString = "&nbsp;&nbsp;&nbsp;&nbsp;"
		    // Loop through the properties/functions
		    var properties = '';
		    for (var propertyName in obj) {
		        // Check if it's NOT a function
		        if (!(obj[propertyName] instanceof Function)) {
		            if (typeof(obj[propertyName]) == 'object'){
						if (level < 3){							
		                	properties +='<li>'+propertyName+':'+newLine+juxtapo.utils.objectToStructureString(obj[propertyName],tab+tabString,level+1) + '</li>';
						}
		            }else{
		                properties +='<li>'+propertyName+':'+obj[propertyName] + '</li>';
		            }
		        }
		    }
		    // Loop through the properties/functions
		    var functions = '';
		    for (var functionName in obj) {
		        // Check if it�s a function
		        if (obj[functionName] instanceof Function) {
		            functions +='<li>'+functionName + '</li>';
		        }
		    }
		    var sReturn = '';
		    if (properties !=''){sReturn+='<li>Properties : <ul>' + properties + '</ul></li>';}
		    if (functions !=''){sReturn+=newLine+tab+'<li>Functions : <ul>'+functions + '</ul></li>';}
		    return '<ul>' + sReturn + '</ul>';
		},
		preventDefaultEventAction : function(event){
			event.preventDefault();
			event.keyCode = 0;
			event.which = 0;
			if (event.originalEvent){
				event.originalEvent.keyCode = 0;
			}
		},
		readCookie : function(name) {
			var nameEQ = name + "=";
			var ca = document.cookie.split(';');
			for(var i=0;i < ca.length;i++) {
				var c = ca[i];
				while (c.charAt(0)==' ') c = c.substring(1,c.length);
				if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
			}
			return null;
		},
		requireResource : function(url,callBack){
			var head = document.getElementsByTagName('head')[0];
			var callBackRun = false;
			var resourceLoaded = false;

			if (url.substr(url.lastIndexOf(".")) == ".css"){
				var link = document.createElement('link');
				link.setAttribute('rel','stylesheet');
				link.setAttribute('type','text/css');
				link.setAttribute('href',url);
				head.appendChild(link);
				return link;

			}else if (url.substr(url.lastIndexOf(".")) == ".js"){
				var script = document.createElement('script');
				script.type= 'text/javascript';
				if (typeof(callBack) != 'undefined'){
					script.onreadystatechange= function () {
					  if (this.readyState == 'complete' && !callBackRun) {
					  	callBackRun = true;
						resourceLoaded = true;
						if (typeof(callBack) != 'undefined') callBack.call(script,url);
					  }
					};
					script.onload = function(){
						if (!callBackRun){
							callBackRun = true;
							resourceLoaded = true;
							if (typeof(callBack) != 'undefined') callBack.call(script,url);
						}
					};
				}
				script.src = url;
				$(script).appendTo(head);
				head.appendChild(script);
				return script;
			}
			return null;
		},
		resolveAbsoluteUrl : function(baseUrl,relativeUrl) {
		    if (relativeUrl.substr(0, 1) == '/') {
		        return baseUrl + relativeUrl; 
		    }else if (self.isAbsoluteUrl(relativeUrl)) {
		        return relativeUrl;
		    } else {
		        var Loc = baseUrl;
		        Loc = Loc.substring(0, Loc.lastIndexOf('/'));
		        while (/^\.\./.test(relativeUrl)) {
		            Loc = Loc.substring(0, Loc.lastIndexOf('/'));
		            relativeUrl = relativeUrl.substring(3);
		        }
		        relativeUrl = self.String.ltrim(relativeUrl, "/");
		        return Loc + '/' + relativeUrl;
		    }
		},
		/**
		 * A namespace of string functions
		 * @namespace 
		 */
		String : {
			contains : function(s,containing){
				return s.indexOf(containing) > -1;
			},
			ltrim : function(str, chars) {
			    chars = chars || "\\s";
			    return str.replace(new RegExp("^[" + chars + "]+", "g"), "");
			},
			replace : function(str, oldChar, newChar) {
			    var RegEx = new RegExp('['+oldChar+']','g');
			    return str.replace(RegEx, newChar);
			},
			right : function(str, n){
			        if (n <= 0)     // Invalid bound, return blank string
			           return "";
			        else if (n > String(str).length)   // Invalid bound, return
			           return str;                     // entire string
			        else { // Valid bound, return appropriate substring
			           var iLen = String(str).length;
			           return String(str).substring(iLen, iLen - n);
			        }
			},
			rtrim : function(str, chars) {
			    chars = chars || "\\s";
			    return str.replace(new RegExp("[" + chars + "]+$", "g"), "");
			},
			trim : function(str, chars) {
			    return self.String.ltrim(self.String.rtrim(str, chars), chars);
			}
		}
	};

	var self = juxtapo.utils;
	String.prototype.juxtapoContains = function(containing){
		return juxtapo.utils.String.contains(this,containing);
	};
	
})();


/**
 * @author david
 */
/*
 * juxtapo.ui
 * ------------------------------------------------------------------------
 */
/**
 * UI namespace of controls
 * @namespace
 */
juxtapo.ui = {};

(function() {

	_openDropDown = null;
	
	/**
	 * Creates a new dropDown control which puts a button in the tool strip and gives a popup
	 * @class Represents a dropDown control
	 * @constructor
	 * @param {Object} options
	 * @param {Object} options.style
	 * @property {HtmlElement} controller The button the sits on the toolstrip
	 * @property {HtmlElement} contents The main lightbox container
	 * @property {bool} expanded
	 * @property {Object} settings
	 */
	juxtapo.ui.dropDown = function(options) {
		this._init(options);
	};
	juxtapo.ui.dropDown.prototype = {
		// properties
		afterOpen : null,
		beforeOpen : null,
		controller : null,
		contents : null,
		expanded : null,
		settings : {
			cssClass : '',
			style : {
				height : '548px',
				width : '905px'
			}
		},

		// methods
		/** @private */
		_init : function(options) {
			this.settings = $.extend( {}, this.settings, options);
			this.render();

			var self = this;
			$(document).bind("keydown", function(e) {
				if (self.expanded && e.which == 27) {
					self.show(false);
					return false;
				}
			});
		},
		contentHtml : function(s) {
			if (typeof s == "undefined") {
				return $(this.contents).html();
			} else {
				$(this.contents).html(s);
			}
		},
		/** @private */
		render : function() {
			var dd = this;

			// controller
			this.controller = document.createElement("div");
			$(this.controller).attr("class", "juxtapo-dropDown");
			/** @private */
			this.controller.onclick = function() {
				dd.toggleShow();
			};
			juxtapo.container.appendChild(this.controller);

			// pop up
			this.contents = document.createElement("div");
			$(this.contents)
				.attr("class", ("juxtapo-lightBox"))
				.css(this.settings.style);
			document.getElementsByTagName("body")[0].appendChild(this.contents);

		},
		show : function(b) {
			if (typeof (b) == "undefined")
				b = true;
			if (b && !this.expanded) {
				if (_openDropDown){
					_openDropDown.show(false);
					_openDropDown = null;
				}
				if (this.beforeOpen) {
					this.beforeOpen();
				}
				$(this.contents).show();
				$(this.controller).addClass("juxtapo-btn-open");
				this.expanded = true;
				_openDropDown = this;
				if (this.afterOpen) {
					this.afterOpen();
				}
			} else if (!b) {
				$(this.contents).hide();
				$(this.controller).removeClass("juxtapo-btn-open");
				this.expanded = false;
			}
			return this.expanded;
		},
		text : function(s) {
			if (typeof s == "undefined") {
				return $(this.controller).html();
			} else {
				$(this.controller).html(s);
			}
		},
		toggleShow : function() {
			return this.show(!this.expanded);
		}

	};
})();

/**
 * Creates a new thumbnail control which contains a link to the page
 * a small image and the page name
 * @class Represents a thumbnail control
 * @constructor
 * @property {HtmlElement} caption The Html element containing the thumbnail caption
 * @property {HtmlElement} container The main thumbnail container li
 * @property {juxtapo.designs.designTemplate} designTemplate The designTemplate this thumbnail is associated with
 * @property {HtmlElement} link The Html anchor element for the thumbnail 
 * @property {HtmlSpanElement} imageContainer The Html span element containing the thumbnail image 
 * @property {HtmlImage} image The thumbnail image
 * @property {Object} settings
 */
juxtapo.ui.thumbnail = function(designTemplate, options) {
	this._init(designTemplate, options);
};
juxtapo.ui.thumbnail.prototype = {
	caption : null,
	container : null,
	designTemplate : null,
	link : null,
	imageContainer : null,
	image : null,
	settings : {},

	// methods
	_init : function(designTemplate, options) {
		var self = this;

		self.settings = $.extend( {}, this.settings, options);
		self.designTemplate = designTemplate;

		self.image = $(
				'<img height="220" src="' + designTemplate.imageUrl + '" alt="design image" />')
				.get(0);
		self.imageContainer = $('<span class="juxtapo-thumb-img" />').append(
				self.image).get(0);

		self.caption = $('<span class="juxtapo-thumb-caption" />').html(
				self.designTemplate.paths[0]).get(0);
		self.link = $(
				'<a class="juxtapo-thumb-lnk" style="display:block;" href="' + self.designTemplate.paths[0] + '" />')
				.append(self.imageContainer).append(self.caption).get(0);
		self.container = $('<li class="juxtapo-thumb" />').append(self.link)
				.get(0);

		designTemplate.setUiThumbnail(self);

		/**
		 * Shows or hides the thumbnail
		 * @function
		 * @name juxtapo.ui.thumbnail.show
		 * @param {bool} [b=true] A boolean value to determine whether to show the thumbnail 
		 */
		self.show = function(b) {
			if (typeof (b) == 'undefined')
				b = true;
			if (b) {
				$(self.container).show();
			} else {
				$(self.container).show();
			}
		};

	}
};

/**
 * Creates a new toolbtn control
 * @class Represents a toolbtn control
 * @constructor
 */
juxtapo.ui.toolbtn = function(options) {
	this._init(options);
};
juxtapo.ui.toolbtn.prototype = {
	container : null,
	contents : null,

	settings : {},

	// methods
	_init : function(designTemplate, options) {
		var self = this;

		self.settings = $.extend( {}, this.settings, options);

		self.contents = $('<span class="juxtapo-toolbtn-contents" />').get(0);
		self.container = $('<a class="juxtapo-toolbtn" />').append(
				self.contents).get(0);

		/**
		 * Adds a listener function which is triggered when a user clicks on the button
		 * @name juxtapo.ui.toolbtn.click
		 * @event
		 * @param {Object} fn
		 */
		self.click = function(fn) {
			$(self.container).click(fn);
			return self;
		};
		/**
		 * Shows or hides the button
		 * @function
		 * @name juxtapo.ui.toolbtn.show
		 * @param {bool} [b=true] A boolean value to determine whether to show the button 
		 */
		self.show = function(b) {
			if (typeof (b) == 'undefined')
				b = true;
			if (b) {
				$(self.container).show();
			} else {
				$(self.container).show();
			}
			return self;
		};
		/**
		 * Sets the contents of the button
		 * @property
		 * @param {Html|String} text
		 */
		self.text = function(text) {
			$(self.contents).html(text);
			return self;
		};
	}
};


(function(){

	var _dropDown = null;

	juxtapo.initComplete(function(){
        _dropDown = new juxtapo.ui.dropDown({style:{height:'300px',width:'300px'}});
        _dropDown.text("?");
		
		var helpHtml = '';
		helpHtml = '' +
		'<h4>Keyboard Shortcuts</h4>' +
		'<table width="100%">' +
		'<tr><td>Move Left</td><td>Ctrl+J [+shift for nudge]</td></tr>' +
		'<tr><td>Move Right</td><td>Ctrl+L [+shift for nudge]</td></tr>' +
		'<tr><td>Move Up</td><td>Ctrl+I [+shift for nudge]</td></tr>' +
		'<tr><td>Move Down</td><td>Ctrl+K [+shift for nudge]</td></tr>' +
		'<tr><td>Transparency Back</td><td>Ctrl+U</td></tr>' +
		'<tr><td>Transparency Forward</td><td>Ctrl+O</td></tr>' +
		'<tr><td>Auto Refresh Play/Stop</td><td>Ctrl+Space</td></tr>' +
		'</table>' +
		'<h4>Docs</h4>' +
		'<ul><li><a href="'+ juxtapo.utils.resolveAbsoluteUrl(juxtapo.coreJsUrl(),'../docs/index.htm') + '">Documentation</a></ul>';
		
		_dropDown.contentHtml(helpHtml);
		
	});


})();


