

/**
 * juxtapo JavaScript Library http://juxtapo.net/
 *
 * Copyright (c) 2009 David Taylor (@davetayls) Licensed under the GNU v3
 * license. http://www.gnu.org/licenses/gpl.html
 * 
 * Version 0.4a
 *
 */

