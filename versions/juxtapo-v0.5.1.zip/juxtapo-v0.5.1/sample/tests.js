module('Core');
test("test test",function(){
	ok(true,"tests loaded");
	//ok(false,"test fail");
});
